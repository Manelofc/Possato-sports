import React from 'react';

function HomePage() {
  return (
    <div className="min-h-screen bg-blue-900 text-white">
      <header className="p-6 bg-blue-800 shadow-md">
        <h1 className="text-3xl font-bold">Possato Sports</h1>
        <p className="text-sm text-blue-200">Sua loja de camisas de time</p>
      </header>
      <main className="p-6">
        <div className="bg-blue-700 p-4 rounded-xl text-center mb-6">
          <h2 className="text-xl font-bold">Promoção especial!</h2>
          <p className="text-sm">Frete grátis para todo o Brasil</p>
        </div>
        <input type="text" placeholder="Buscar camisas..." className="w-full p-2 rounded text-black mb-4" />
        <div className="grid grid-cols-2 gap-4">
          <button className="bg-blue-600 hover:bg-blue-500 p-4 rounded">Times</button>
          <button className="bg-blue-600 hover:bg-blue-500 p-4 rounded">Masculino</button>
          <button className="bg-blue-600 hover:bg-blue-500 p-4 rounded">Feminino</button>
          <button className="bg-blue-600 hover:bg-blue-500 p-4 rounded">Infantil</button>
        </div>
      </main>
    </div>
  );
}

export default HomePage;